# Tela de Login
Tela básica de usuario - HTML5 &amp; CSS3

Esse é apenas uma exercicio que fiz para brincar com o css, sinta-se livre para usa-lo ^-^


# Aviso 

Caso já tenha o node instalado na sua maquina, instale o `http-server`, seguindo o código abaixo
`npm install --global http-server`

Logo após a instalação ter terminado entre na pasta pelo terminal e rode `http-server` isso vai gerar uma url mais agradavel

## Caso não tenha o node

Só aperte no `index.html` mesmo, vida que segue ^-^.


*Obrigado*
### Acidiney Dias

